from twilio.rest import Client

account_sid = 'ACa7639e82a2d1aa31daa061e71d54961a'  #this is your account SID
auth_token = 'e00b9593714384975f27881b000f6b78'     #this is your own auth_token
client = Client(account_sid, auth_token)

message = """Subject: Second COVID-19 Vaccination Reminder

    Hello {First} {Last} your second COVID 19 vaccination is coming up on 09/17/2022."""

FirstName = 'Ha TungTung'
LastName = 'Tran'



message = client.messages.create(
                    body=message.format(
                        First=FirstName, Last=LastName
                        ),
                    from_="+18447770939", #this is your own Twilio number
                    to='+16692736729'  #this is your own phone number to receive the text msg
                    )

print(message.sid)


