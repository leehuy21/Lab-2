#Make sure you pip install yagmail
import yagmail

from_address = 'ha.t.tran02@sjsu.edu' #this is your own gmail account
app_password = 'uespuvdbiimcbsno' # a token for gmail, this is the app password from Gmail Security
to_address = 'harrykane1204@gmail.com'   #send test to another email or the same email is OK

subject = 'Test sending email using yagmail'  #modify the subject line anyway you like
content = ['Hello EE104ers','cat.jpg','test.png']  #you can have different email and attachment

with yagmail.SMTP(from_address, app_password) as yag:
    yag.send(to_address, subject, content)
    print('Sent email successfully')  #you can have different success message
    